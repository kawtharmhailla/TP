package src;
import java.io.*;
import java.time.LocalDateTime;
import java.util.*;

public class AlKendiApp {

    private static final File WORKSPACE = new File("workspace");
    private static final File DATA = new File(WORKSPACE, "data");
    private static final File LOGS = new File(WORKSPACE, "logs");
    private static final File TMP = new File(WORKSPACE, "tmp");
    private static final File PHOTOS = new File(DATA, "photos");

    private static final File STOCK_CSV = new File(DATA, "stock_initial.csv");
    private static final File VENTES_TXT = new File(DATA, "ventes.txt");
    private static final File PRODUITS_SER = new File(DATA, "produits.ser");
    private static final File INDEX_DAT = new File(DATA, "index.dat");
    private static final File APP_LOG = new File(LOGS, "app.log");

    public static void main(String[] args) {
        try {
            q1_createArborescence();
            q1_listWorkspace(WORKSPACE, 0);
            ensureStockCsv();
            List<Produit> produits = q2_importStock();
            q3_writeVenteBuffered(produits.get(0), 2);
            q3_writeVentePrintWriter(produits.get(1), 1);
            q4_appendUtf8("BK001", 3, "Vente spéciale – Algorithmes en Java", 660.0);
            File dummy = new File(TMP, "dummy.bin");
            q5_createDummy(dummy, 16 * 1024);
            q5_copyBinary(dummy, new File(PHOTOS, "BK001.jpg"));
            q6_createIndex(produits);
            long pos = q6_seekByRef("BK003");
            System.out.println("Position BK003 trouvée: " + pos);
            q7_serialize(produits);
            List<Produit> loaded = q7_deserialize();
            System.out.println("Produits désérialisés: " + loaded.size());
        } catch (Exception e) {
            logError("main", e.getMessage());
        }
    }

    private static void q1_createArborescence() {
        DATA.mkdirs(); LOGS.mkdirs(); TMP.mkdirs(); PHOTOS.mkdirs();
        try {
            STOCK_CSV.createNewFile();
            VENTES_TXT.createNewFile();
            PRODUITS_SER.createNewFile();
            INDEX_DAT.createNewFile();
        } catch (IOException e) { logError("createArborescence", e.getMessage()); }
    }

    private static void q1_listWorkspace(File dir, int indent) {
        if (dir.exists()) {
            String prefix = " ".repeat(indent);
            System.out.println(prefix + "[DIR] " + dir.getName());
            File[] files = dir.listFiles();
            if (files != null) {
                for (File f : files) {
                    if (f.isDirectory()) q1_listWorkspace(f, indent + 2);
                    else System.out.println(prefix + "  [FILE] " + f.getName() + " (" + f.length() + " bytes)");
                }
            }
        }
    }

    private static void ensureStockCsv() {
        try {
            if (STOCK_CSV.length() == 0) {
                PrintWriter pw = new PrintWriter(new FileWriter(STOCK_CSV));
                pw.println("REF;DESIGNATION;PRIX;QTE");
                pw.println("BK001;Algorithmes en Java;220.0;15");
                pw.println("BK002;Programmation Réseau;180.5;10");
                pw.println("BK003;Structures de Données;199.9;7");
                pw.println("BK004;Systèmes et Réseaux;250.0;5");
                pw.println("BK005;Programmation Orientée Objet;210.0;12");
                pw.close();
            }
        } catch (IOException e) { logError("ensureStockCsv", e.getMessage()); }
    }

    private static List<Produit> q2_importStock() {
        List<Produit> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(STOCK_CSV))) {
            String line = br.readLine();
            while ((line = br.readLine()) != null) {
                String[] t = line.split(";");
                if (t.length == 4) list.add(new Produit(t[0], t[1], Double.parseDouble(t[2]), Integer.parseInt(t[3])));
            }
        } catch (IOException e) { logError("importStock", e.getMessage()); }
        return list;
    }

    private static void q3_writeVenteBuffered(Produit p, int qte) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(VENTES_TXT, true))) {
            bw.write(LocalDateTime.now() + ";" + p.getRef() + ";" + qte + ";" + (p.getPrix() * qte));
            bw.newLine();
        } catch (IOException e) { logError("writeVenteBuffered", e.getMessage()); }
    }

    private static void q3_writeVentePrintWriter(Produit p, int qte) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(VENTES_TXT, true))) {
            pw.println(LocalDateTime.now() + ";" + p.getRef() + ";" + qte + ";" + (p.getPrix() * qte));
        } catch (IOException e) { logError("writeVentePrintWriter", e.getMessage()); }
    }

    private static void q4_appendUtf8(String ref, int qte, String designation, double montant) {
        try (OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(VENTES_TXT, true), "UTF-8")) {
            BufferedWriter bw = new BufferedWriter(osw);
            bw.write(LocalDateTime.now() + ";" + ref + ";" + qte + ";" + montant + ";" + designation);
            bw.newLine();
            bw.close();
        } catch (IOException e) { logError("appendUtf8", e.getMessage()); }
    }

    private static void q5_createDummy(File f, int size) {
        try (FileOutputStream fos = new FileOutputStream(f)) {
            byte[] buf = new byte[1024];
            Random r = new Random();
            int remaining = size;
            while (remaining > 0) {
                r.nextBytes(buf);
                fos.write(buf, 0, Math.min(remaining, buf.length));
                remaining -= buf.length;
            }
        } catch (IOException e) { logError("createDummy", e.getMessage()); }
    }

    private static void q5_copyBinary(File src, File dest) {
        try (FileInputStream in = new FileInputStream(src); FileOutputStream out = new FileOutputStream(dest)) {
            byte[] buf = new byte[1024]; int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        } catch (IOException e) { logError("copyBinary", e.getMessage()); }
    }

    private static void q6_createIndex(List<Produit> produits) {
        try (RandomAccessFile raf = new RandomAccessFile(INDEX_DAT, "rw")) {
            raf.setLength(0);
            for (int i = 0; i < produits.size(); i++) {
                raf.writeUTF(produits.get(i).getRef());
                raf.writeLong(i * 1000L);
            }
        } catch (IOException e) { logError("createIndex", e.getMessage()); }
    }

    private static long q6_seekByRef(String ref) {
        try (RandomAccessFile raf = new RandomAccessFile(INDEX_DAT, "r")) {
            raf.seek(0);
            while (raf.getFilePointer() < raf.length()) {
                String r = raf.readUTF(); long pos = raf.readLong();
                if (r.equals(ref)) return pos;
            }
        } catch (IOException e) { logError("seekByRef", e.getMessage()); }
        return -1;
    }

    private static void q7_serialize(List<Produit> list) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(PRODUITS_SER))) {
            oos.writeObject(list);
        } catch (IOException e) { logError("serialize", e.getMessage()); }
    }

    @SuppressWarnings("unchecked")
    private static List<Produit> q7_deserialize() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(PRODUITS_SER))) {
            return (List<Produit>) ois.readObject();
        } catch (Exception e) { logError("deserialize", e.getMessage()); return new ArrayList<>(); }
    }

    private static void logError(String operation, String msg) {
        try (FileWriter fw = new FileWriter(APP_LOG, true)) {
            fw.write(LocalDateTime.now() + " | " + operation + " | " + msg + "\\n");
        } catch (IOException ignored) {}
    }
}
