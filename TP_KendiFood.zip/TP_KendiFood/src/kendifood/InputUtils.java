package kendifood;

import java.util.Scanner;

public class InputUtils {
    private static final Scanner sc = new Scanner(System.in);

    public static int lireEntier(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = sc.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Entrée invalide, réessayez.");
            }
        }
    }

    public static String lireLigne(String prompt) {
        System.out.print(prompt);
        return sc.nextLine();
    }
}
