package kendifood;

import java.io.*;
import java.nio.file.*;

public class Catalogue {
    private Article[] articles;
    private int size;
    private int[][] stats;

    public Catalogue(int capacity) {
        if (capacity <= 0) capacity = 10;
        this.articles = new Article[capacity];
        this.size = 0;
        this.stats = new int[capacity][2];
    }

    public Catalogue() { this(10); }

    private void ensureCapacity(int minAdditional) {
        if (size + minAdditional <= articles.length) return;
        int newCap = articles.length + Math.max(5, minAdditional);
        Article[] newArr = new Article[newCap];
        int[][] newStats = new int[newCap][2];
        for (int i = 0; i < size; i++) {
            newArr[i] = articles[i];
            newStats[i][0] = stats[i][0];
            newStats[i][1] = stats[i][1];
        }
        articles = newArr;
        stats = newStats;
    }

    public void ajouterArticle(Article a) {
        if (a == null) throw new IllegalArgumentException("article null");
        ensureCapacity(1);
        articles[size++] = a;
    }

    public int trouverIndexParId(String id) {
        if (id == null) return -1;
        for (int i = 0; i < size; i++) {
            if (id.equals(articles[i].getId())) return i;
        }
        return -1;
    }

    public Article getArticleById(String id) {
        int idx = trouverIndexParId(id);
        return idx == -1 ? null : articles[idx];
    }

    public void afficherCatalogue() {
        System.out.println("=== CATALOGUE ===");
        for (int i = 0; i < size; i++) System.out.println(articles[i]);
    }

    public int chargerDepuisFichier(String chemin) throws IOException {
        Path p = Paths.get(chemin);
        if (!Files.exists(p)) throw new FileNotFoundException("Chemin introuvable : " + chemin);
        int loaded = 0;
        try (BufferedReader br = Files.newBufferedReader(p)) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(";");
                if (parts.length != 4) continue;
                String id = parts[0].trim();
                String lib = parts[1].trim();
                int prix = Integer.parseInt(parts[2].trim());
                int stock = Integer.parseInt(parts[3].trim());
                try {
                    ajouterArticle(new Article(id, lib, prix, stock));
                    loaded++;
                } catch (IllegalArgumentException ignored) {}
            }
        }
        return loaded;
    }

    public int sauvegarderVersFichier(String chemin) throws IOException {
        Path p = Paths.get(chemin);
        try (BufferedWriter bw = Files.newBufferedWriter(p)) {
            for (int i = 0; i < size; i++) {
                Article a = articles[i];
                bw.write(String.format("%s;%s;%d;%d", a.getId(), a.getLibelle(), a.getPrixCentimes(), a.getStock()));
                bw.newLine();
            }
        }
        return size;
    }
}
