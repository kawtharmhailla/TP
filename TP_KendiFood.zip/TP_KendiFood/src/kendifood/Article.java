package kendifood;

public class Article {
    private String id;
    private String libelle;
    private int prixCentimes;
    private int stock;

    public Article(String id, String libelle, int prixCentimes, int stock) {
        if (id == null || id.trim().isEmpty()) throw new IllegalArgumentException("id vide interdit");
        if (libelle == null || libelle.trim().isEmpty()) throw new IllegalArgumentException("libelle vide interdit");
        if (prixCentimes < 0) throw new IllegalArgumentException("prix negatif interdit");
        if (stock < 0) throw new IllegalArgumentException("stock negatif interdit");
        this.id = id;
        this.libelle = libelle;
        this.prixCentimes = prixCentimes;
        this.stock = stock;
    }

    public String getId() { return id; }
    public String getLibelle() { return libelle; }
    public int getPrixCentimes() { return prixCentimes; }
    public int getStock() { return stock; }

    public void setStock(int stock) {
        if (stock < 0) throw new IllegalArgumentException("stock negatif interdit");
        this.stock = stock;
    }

    @Override
    public String toString() {
        return String.format("%-10s | %-20s | %6d cts | stock=%d", id, libelle, prixCentimes, stock);
    }
}
