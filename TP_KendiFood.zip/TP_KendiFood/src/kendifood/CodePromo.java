package kendifood;

public class CodePromo {
    private String code;
    private int pourcentage;

    public CodePromo(String code, int pourcentage) {
        if (code == null || code.trim().isEmpty()) throw new IllegalArgumentException("code vide");
        if (pourcentage < 1 || pourcentage > 50) throw new IllegalArgumentException("pct hors plage");
        this.code = code;
        this.pourcentage = pourcentage;
    }

    public String getCode() { return code; }
    public int getPourcentage() { return pourcentage; }

    public static CodePromo trouverParCode(CodePromo[] array, String code) {
        if (array == null || code == null) return null;
        for (CodePromo cp : array) if (cp.getCode().equals(code)) return cp;
        return null;
    }
}
