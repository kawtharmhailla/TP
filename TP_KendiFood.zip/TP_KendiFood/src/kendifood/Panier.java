package kendifood;

public class Panier {
    private LignePanier[] lignes;
    private int size;

    public Panier(int initialCap) {
        if (initialCap <= 0) initialCap = 5;
        this.lignes = new LignePanier[initialCap];
        this.size = 0;
    }

    public Panier() { this(5); }

    private void ensureCapacity() {
        if (size < lignes.length) return;
        LignePanier[] newArr = new LignePanier[lignes.length + 5];
        System.arraycopy(lignes, 0, newArr, 0, size);
        lignes = newArr;
    }

    public void ajouterOuActualiser(Article art, int qte) {
        for (int i = 0; i < size; i++) {
            if (lignes[i].getArticle().getId().equals(art.getId())) {
                lignes[i].setQuantite(lignes[i].getQuantite() + qte);
                return;
            }
        }
        ensureCapacity();
        lignes[size++] = new LignePanier(art, qte);
    }

    public boolean supprimerParId(String id) {
        for (int i = 0; i < size; i++) {
            if (lignes[i].getArticle().getId().equals(id)) {
                System.arraycopy(lignes, i + 1, lignes, i, size - i - 1);
                lignes[--size] = null;
                return true;
            }
        }
        return false;
    }

    public int totalBrut() {
        int tot = 0;
        for (int i = 0; i < size; i++) tot += lignes[i].ligneTotal();
        return tot;
    }

    public LignePanier[] getLignes() {
        LignePanier[] copy = new LignePanier[size];
        System.arraycopy(lignes, 0, copy, 0, size);
        return copy;
    }

    public String genererRecu(String codeOptionnel, CodePromo[] codes) {
        StringBuilder sb = new StringBuilder("===== REÇU KendiFood =====\n\n");
        for (int i = 0; i < size; i++) {
            LignePanier lp = lignes[i];
            sb.append(String.format("%-10s x%d -> %d cts\n", lp.getArticle().getId(), lp.getQuantite(), lp.ligneTotal()));
        }
        int brut = totalBrut();
        sb.append("\nTotal brut : ").append(brut).append(" cts\n");
        if (codeOptionnel != null && !codeOptionnel.trim().isEmpty()) {
            CodePromo cp = CodePromo.trouverParCode(codes, codeOptionnel);
            if (cp != null) {
                sb.append("Code appliqué : ").append(cp.getCode()).append(" (-").append(cp.getPourcentage()).append("%)\n");
                sb.append("Total à payer : ").append(brut - cp.getPourcentage() * brut / 100).append(" cts\n");
            } else {
                sb.append("Code inconnu : ").append(codeOptionnel).append("\n");
                sb.append("Total à payer : ").append(brut).append(" cts\n");
            }
        }
        return sb.toString();
    }
    
    public void afficherPanier() {
        System.out.println("=== PANIER ===");
        if (size == 0) {
            System.out.println("(panier vide)");
            return;
        }
        for (int i = 0; i < size; i++) {
            System.out.println(lignes[i].toString());
        }
        System.out.println("Total brut : " + totalBrut() + " cts");
    }
}
