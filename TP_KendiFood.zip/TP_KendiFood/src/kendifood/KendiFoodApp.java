package kendifood;

import java.io.IOException;

public class KendiFoodApp {

    private static CodePromo[] codes = {
        new CodePromo("KENDI10", 10),
        new CodePromo("SUMMER20", 20),
        new CodePromo("WELCOME5", 5)
    };

    public static void main(String[] args) {
        Catalogue catalogue = new Catalogue(10);
        catalogue.ajouterArticle(new Article("KIT_BOL1", "Bol vegetalien", 5990, 12));
        catalogue.ajouterArticle(new Article("TOMATE3", "Tomates x3", 990, 40));
        catalogue.ajouterArticle(new Article("PAIN1", "Pain complet", 150, 30));
        Panier panier = new Panier();
        boolean quitter = false;
        while (!quitter) {
            System.out.println("\n--- KendiFood Menu ---");
            System.out.println("1. Afficher catalogue");
            System.out.println("2. Ajouter article au catalogue");
            System.out.println("3. Ajouter au panier");
            System.out.println("4. Supprimer du panier");
            System.out.println("5. Afficher panier");
            System.out.println("6. Générer reçu");
            System.out.println("0. Quitter");
            String choix = InputUtils.lireLigne("Choix> ").trim();
            switch (choix) {
                case "1" -> catalogue.afficherCatalogue();
                case "2" -> ajouterArticleCatalogue(catalogue);
                case "3" -> ajouterAuPanier(catalogue, panier);
                case "4" -> supprimerDuPanier(catalogue, panier);
                case "5" -> panier.afficherPanier();
                case "6" -> System.out.println(panier.genererRecu(InputUtils.lireLigne("Code promo: "), codes));
                case "0" -> quitter = true;
                default -> System.out.println("Choix invalide");
            }
        }
    }

    private static void ajouterArticleCatalogue(Catalogue cat) {
        String id = InputUtils.lireLigne("id: ");
        String lib = InputUtils.lireLigne("libelle: ");
        int prix = InputUtils.lireEntier("prix (cts): ");
        int stock = InputUtils.lireEntier("stock: ");
        try {
            cat.ajouterArticle(new Article(id, lib, prix, stock));
            System.out.println("Ajouté.");
        } catch (IllegalArgumentException e) {
            System.out.println("Erreur: " + e.getMessage());
        }
    }

    private static void ajouterAuPanier(Catalogue cat, Panier panier) {
        String id = InputUtils.lireLigne("id article: ");
        Article a = cat.getArticleById(id);
        if (a == null) {
            System.out.println("Inconnu");
            return;
        }
        int qte = InputUtils.lireEntier("quantité: ");
        if (qte > a.getStock()) {
            System.out.println("Stock insuffisant.");
            return;
        }
        a.setStock(a.getStock() - qte);
        panier.ajouterOuActualiser(a, qte);
    }

    private static void supprimerDuPanier(Catalogue cat, Panier panier) {
        String id = InputUtils.lireLigne("id: ");
        LignePanier[] lignes = panier.getLignes();
        for (LignePanier lp : lignes) {
            if (lp.getArticle().getId().equals(id)) {
                Article a = cat.getArticleById(id);
                if (a != null) a.setStock(a.getStock() + lp.getQuantite());
                break;
            }
        }
        panier.supprimerParId(id);
    }
}
