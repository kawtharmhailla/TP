package tp.collections;

public class ClientFidel extends Client {
    private String codeFidelite;
    private float tauxReduction;

    public ClientFidel(String codeClient, String nomClient, String adrClient,
                       String codeFidelite, float tauxReduction) {
        super(codeClient, nomClient, adrClient);
        this.codeFidelite = codeFidelite;
        this.tauxReduction = tauxReduction;
    }

    public String getCodeFidelite() { return codeFidelite; }
    public float getTauxReduction() { return tauxReduction; }

    @Override
    public String toString() {
        return super.toString() + "ClientFidel{codeFidelite=" + codeFidelite +
               ", tauxReduction=" + tauxReduction + "}\n";
    }
}