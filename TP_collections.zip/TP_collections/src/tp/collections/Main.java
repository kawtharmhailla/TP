package tp.collections;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        try {
            // 1) Création de commandes (utilise SimpleDateFormat pour créer des Date)
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Commande c1 = new Commande(1, sdf.parse("2024-03-10"), "Fournisseur A");
            Commande c2 = new Commande(2, sdf.parse("2024-01-15"), "Fournisseur B");
            Commande c3 = new Commande(3, sdf.parse("2024-02-20"), "Fournisseur A");
            Commande c4 = new Commande(2, sdf.parse("2024-01-15"), "Fournisseur B"); // même numCommande que c2 -> doublon logique

            // 2) Création de clients
            Client client1 = new Client("C001", "Ali", "Casablanca", "0600000001");
            ClientFidel client2 = new ClientFidel("C002", "Fatima", "Rabat", "F100", 0.10f);

            // 3) Enregistrer des commandes
            client1.enregistrerCommande(c1);
            client1.enregistrerCommande(c3);
            client1.enregistrerCommande(c2);
            client1.enregistrerCommande(c4); // on ajoute volontairement un doublon (num=2)

            client2.enregistrerCommande(c2);

            // 4) Tri des commandes d'un client (Collections.sort utilise compareTo de Commande)
            System.out.println("Avant tri (client1):");
            for (Commande c : client1.getListeCommandes()) System.out.println(c);
            Collections.sort(client1.getListeCommandes());
            System.out.println("\nAprès tri (client1) par dateCommande:");
            for (Commande c : client1.getListeCommandes()) System.out.println(c);

            // 5) Utiliser un Set pour éviter doublons (base sur equals/hashCode de Commande)
            Set<Commande> setCommandes = new HashSet<>(client1.getListeCommandes());
            System.out.println("\nSet (sans doublons) :");
            for (Commande c : setCommandes) System.out.println(c);

            // 6) Utiliser une Map pour associer chaque codeClient à son Client
            Map<String, Client> mapClients = new HashMap<>();
            mapClients.put(client1.getCodeClient(), client1);
            mapClients.put(client2.getCodeClient(), client2);

            System.out.println("\nRécupération via Map (C002):");
            System.out.println(mapClients.get("C002"));

            // 7) Écriture des informations des clients dans un fichier texte
            File file = new File("clients.txt");
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                for (Client cl : mapClients.values()) {
                    writer.write("=== CLIENT ===\n");
                    writer.write(cl.toString());
                    writer.write("\n");
                }
            } // try-with-resources ferme automatiquement
            System.out.println("Fichier 'clients.txt' écrit avec succès.");

            // 8) Lecture du fichier et affichage dans la console (gestion d'IOException)
            System.out.println("\n--- Contenu du fichier clients.txt ---");
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println(line);
                }
            }

            // 9) Test suppression d'une commande
            boolean suppr = client1.supprimerCommande(2); // supprime les commandes avec numCommande=2 (première occurrence)
            System.out.println("\nSuppression numéro 2 dans client1 : " + suppr);
            System.out.println("Commandes client1 après suppression:");
            for (Commande c : client1.getListeCommandes()) System.out.println(c);

        } catch (ParseException pe) {
            System.err.println("Format de date invalide : " + pe.getMessage());
        } catch (IOException ioe) {
            System.err.println("Erreur fichier : " + ioe.getMessage());
        } catch (Exception e) {
            System.err.println("Erreur inattendue : " + e.getMessage());
            e.printStackTrace();
        }
    }
}