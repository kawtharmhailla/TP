package tp.collections;

import java.util.Date;
import java.util.Objects;

public class Commande implements Comparable<Commande> {
    private int numCommande;
    private Date dateCommande;
    private String nomFournisseur;

    public Commande(int numCommande, Date dateCommande, String nomFournisseur) {
        this.numCommande = numCommande;
        this.dateCommande = dateCommande;
        this.nomFournisseur = nomFournisseur;
    }

    // Getters
    public int getNumCommande() { return numCommande; }
    public Date getDateCommande() { return dateCommande; }
    public String getFournisseur() { return nomFournisseur; }

    // Setters
    public void setNumCommande(int numCommande) { this.numCommande = numCommande; }
    public void setDateCommande(Date dateCommande) { this.dateCommande = dateCommande; }
    public void setFournisseur(String nomFournisseur) { this.nomFournisseur = nomFournisseur; }

    @Override
    public String toString() {
        return "Commande{" +
               "numCommande=" + numCommande +
               ", dateCommande=" + dateCommande +
               ", nomFournisseur='" + nomFournisseur + '\'' +
               '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Commande)) return false;
        Commande other = (Commande) obj;
        return this.numCommande == other.numCommande; // comparaison basée sur NumCommande
    }

    @Override
    public int hashCode() {
        return Objects.hash(numCommande);
    }

    @Override
    public int compareTo(Commande other) {
        // Tri par dateCommande (ancienne -> récente). Si nulls, on gère.
        if (this.dateCommande == null && other.dateCommande == null) return 0;
        if (this.dateCommande == null) return -1;
        if (other.dateCommande == null) return 1;
        return this.dateCommande.compareTo(other.dateCommande);
    }
}