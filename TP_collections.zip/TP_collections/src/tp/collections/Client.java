package tp.collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Client {
    private String codeClient;
    private String nomClient;
    private String adrClient;
    private String telClient;
    private List<Commande> listeCommandes;

    public Client(String codeClient, String nomClient, String adrClient) {
        this.codeClient = codeClient;
        this.nomClient = nomClient;
        this.adrClient = adrClient;
        this.telClient = "";
        this.listeCommandes = new ArrayList<>();
    }

    public Client(String codeClient, String nomClient, String adrClient, String telClient) {
        this(codeClient, nomClient, adrClient);
        this.telClient = telClient;
    }

    // Getters
    public String getCodeClient() { return codeClient; }
    public String getNomClient() { return nomClient; }
    public String getAdrClient() { return adrClient; }
    public String getTelClient() { return telClient; }
    public List<Commande> getListeCommandes() { return listeCommandes; }

    // Enregistrer une commande
    public boolean enregistrerCommande(Commande cmd) {
        if (cmd == null) return false;
        return listeCommandes.add(cmd);
    }

    // Supprimer une commande en se basant sur numCommande
    public boolean supprimerCommande(int numCommande) {
        Iterator<Commande> it = listeCommandes.iterator();
        while (it.hasNext()) {
            Commande c = it.next();
            if (c.getNumCommande() == numCommande) {
                it.remove();
                return true;
            }
        }
        return false; // numéro non trouvé
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Client{code=").append(codeClient)
          .append(", nom=").append(nomClient)
          .append(", adr=").append(adrClient)
          .append(", tel=").append(telClient)
          .append("}\nCommandes:\n");
        for (Commande c : listeCommandes) {
            sb.append("  ").append(c).append("\n");
        }
        return sb.toString();
    }
}